'use client';

import { Suspense } from 'react';
import { useMousePosition } from '../../hooks/useMousePosition';
import { useScrollProgress } from '../../hooks/useScrollProgress';
import { HeroCanvas } from '../canvas/HeroCanvas';
import { ScrambleText } from '../ui/ScrambleText';

export function Hero() {
  const { x: mouseX, y: mouseY } = useMousePosition();
  const scrollProgress = useScrollProgress();

  return (
    <section className="relative min-h-[100dvh] overflow-hidden bg-ivoire">
      <div className="absolute inset-0 z-[1]">
        <Suspense fallback={null}>
          <HeroCanvas
            mouseX={mouseX}
            mouseY={mouseY}
            scrollProgress={scrollProgress}
          />
        </Suspense>
      </div>

      <div
        className="hero-brume pointer-events-none absolute inset-0 z-[2] mix-blend-soft-light"
        aria-hidden
        style={{
          background: `radial-gradient(ellipse at 20% 80%, rgba(232, 197, 192, 0.4) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 20%, rgba(184, 162, 200, 0.25) 0%, transparent 55%)`,
        }}
      />

      <div className="relative z-[5] flex min-h-[100dvh] flex-col items-center justify-between px-[6vw] pb-[6vh] pt-[12vh] mix-blend-difference pointer-events-none">
        <p
          className="text-center font-body text-[0.7rem] font-extralight uppercase tracking-[0.5em] text-[#D4A574]"
          style={{ fontWeight: 200 }}
        >
          Parfumerie niche - Bordeaux 2026
        </p>

        <div className="flex flex-col items-center text-center">
          <h1 className="font-display text-[clamp(3.5rem,11vw,8.5rem)] font-light italic leading-none tracking-tight text-[#F7F1EA]">
            <ScrambleText text="ORIANE" delay={1400} />
          </h1>
          <div
            className="mt-8 max-w-xl font-body text-[0.95rem] font-light uppercase tracking-[0.3em] text-[#F7F1EA]"
            style={{ fontWeight: 300 }}
          >
            <ScrambleText
              text="Trois aubes. Trois fragrances. Une maison."
              delay={2800}
            />
          </div>
        </div>

        <p
          className="hero-bob text-center font-body text-[0.65rem] font-extralight uppercase tracking-[0.4em] text-[#F7F1EA]"
          style={{ fontWeight: 200 }}
        >
          Scroll ↓
        </p>
      </div>
    </section>
  );
}
